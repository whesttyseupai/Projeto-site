import { useState } from "react";
import { Menu, X, LogOut, Copy, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

type Tab =
  | "dashboard"
  | "create-reseller"
  | "manage-resellers"
  | "create-client"
  | "create-key"
  | "active-keys"
  | "deactivated-keys";

export default function AdminDashboard() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [, navigate] = useLocation();

  // Form states
  const [resellerUsername, setResellerUsername] = useState("");
  const [resellerPassword, setResellerPassword] = useState("");
  const [resellerEmail, setResellerEmail] = useState("");
  const [resellerDays, setResellerDays] = useState(30);

  const [keyDays, setKeyDays] = useState(30);
  const [searchActive, setSearchActive] = useState("");
  const [searchDeactivated, setSearchDeactivated] = useState("");
  const [generatedKey, setGeneratedKey] = useState<{ key: string; expiresAt: Date } | null>(null);

  // Mutations
  const createResellerMutation = trpc.reseller.create.useMutation({
    onSuccess: () => {
      utils.reseller.list.invalidate();
      alert("Revendedor criado com sucesso!");
      setResellerUsername("");
      setResellerPassword("");
      setResellerEmail("");
      setResellerDays(30);
    },
    onError: (error) => {
      alert(error.message || "Erro ao criar revendedor");
    },
  });

  const createKeyMutation = trpc.proxyKeys.create.useMutation({
    onSuccess: (data) => {
      setGeneratedKey(data);
      setKeyDays(30);
    },
    onError: (error) => {
      alert(error.message || "Erro ao criar chave");
    },
  });

  const logoutMutation = trpc.admin.logout.useMutation({
    onSuccess: () => {
      navigate("/admin");
    },
  });

  const utils = trpc.useUtils();

  // Queries
  const activeKeysQuery = trpc.proxyKeys.listActive.useQuery();
  const deactivatedKeysQuery = trpc.proxyKeys.listDeactivated.useQuery();
  const resellersQuery = trpc.reseller.list.useQuery();

  // Delete reseller mutation
  const deleteResellerMutation = trpc.reseller.delete.useMutation({
    onSuccess: () => {
      utils.reseller.list.invalidate();
      alert("Revendedor deletado com sucesso!");
    },
    onError: (error) => {
      alert(error.message || "Erro ao deletar revendedor");
    },
  });

  const handleCreateReseller = async (e: React.FormEvent) => {
    e.preventDefault();
    await createResellerMutation.mutateAsync({
      username: resellerUsername,
      password: resellerPassword,
      email: resellerEmail || undefined,
      resellerDays: resellerDays,
    });
  };

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    await createKeyMutation.mutateAsync({
      key: `KEY-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      days: keyDays,
      createdBy: 1,
      createdByType: "admin",
    });
  };

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
  };

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    alert("Chave copiada para clipboard!");
  };

  const menuItems = [
    { id: "dashboard", label: "Dashboard" },
    { id: "create-reseller", label: "Criar Revendedor" },
    { id: "manage-resellers", label: "Gerenciar Revendedores" },
    { id: "create-client", label: "Criar Cliente Proxy" },
    { id: "create-key", label: "Criar Chave Key" },
    { id: "active-keys", label: "Chaves Keys Utilizadas" },
    { id: "deactivated-keys", label: "Chaves Keys Desativadas/Expiradas" },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Top Header with Hamburger Menu */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="p-2 hover:bg-slate-800 rounded-lg transition"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <h1 className="text-2xl font-bold text-cyan-400">Proxy Oficial Admin</h1>
          </div>
          <Button
            variant="outline"
            className="border-red-700 text-red-400 hover:bg-red-900/20"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut size={18} className="mr-2" />
            Sair
          </Button>
        </div>

        {/* Dropdown Menu */}
        {menuOpen && (
          <nav className="bg-slate-800 border-t border-slate-700 p-4 space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as Tab);
                  setMenuOpen(false);
                }}
                className={`w-full text-left px-4 py-2 rounded-lg transition ${
                  activeTab === item.id
                    ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
                    : "hover:bg-slate-700 text-slate-300"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="p-8">
        <div className="max-w-6xl mx-auto">
          {/* Dashboard */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-800 rounded-lg p-6 space-y-2">
                  <p className="text-slate-400 text-sm">Chaves Ativas</p>
                  <p className="text-3xl font-bold text-cyan-400">
                    {activeKeysQuery.data?.length || 0}
                  </p>
                </div>
                <div className="bg-slate-800 rounded-lg p-6 space-y-2">
                  <p className="text-slate-400 text-sm">Chaves Expiradas</p>
                  <p className="text-3xl font-bold text-red-400">
                    {deactivatedKeysQuery.data?.length || 0}
                  </p>
                </div>
                <div className="bg-slate-800 rounded-lg p-6 space-y-2">
                  <p className="text-slate-400 text-sm">Revendedores Ativos</p>
                  <p className="text-3xl font-bold text-green-400">
                    {resellersQuery.data?.length || 0}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Create Reseller */}
          {activeTab === "create-reseller" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Criar Revendedor</h1>
              <form onSubmit={handleCreateReseller} className="bg-slate-800 rounded-lg p-6 space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-2">Usuário</label>
                  <input
                    type="text"
                    value={resellerUsername}
                    onChange={(e) => setResellerUsername(e.target.value)}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Senha</label>
                  <input
                    type="password"
                    value={resellerPassword}
                    onChange={(e) => setResellerPassword(e.target.value)}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email (opcional)</label>
                  <input
                    type="email"
                    value={resellerEmail}
                    onChange={(e) => setResellerEmail(e.target.value)}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Tempo de Revenda (dias)</label>
                  <input
                    type="number"
                    min="1"
                    max="365"
                    value={resellerDays}
                    onChange={(e) => setResellerDays(parseInt(e.target.value))}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold"
                  disabled={createResellerMutation.isPending}
                >
                  {createResellerMutation.isPending ? "Criando..." : "Criar Revendedor"}
                </Button>
              </form>
            </div>
          )}

          {/* Manage Resellers */}
          {activeTab === "manage-resellers" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Gerenciar Revendedores</h1>
              {resellersQuery.isLoading ? (
                <p className="text-slate-400">Carregando...</p>
              ) : resellersQuery.data?.length === 0 ? (
                <p className="text-slate-400">Nenhum revendedor criado</p>
              ) : (
                <div className="space-y-3">
                  {resellersQuery.data?.map((reseller) => (
                    <div key={reseller.id} className="bg-slate-800 rounded-lg p-4 space-y-2">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <p className="font-semibold text-cyan-400">Revendedor: {reseller.username}</p>
                          <p className="text-sm text-slate-300 font-mono mt-1">Senha Hash: {reseller.passwordHash.substring(0, 20)}...</p>
                          <p className="text-sm text-slate-400 mt-1">Email: {reseller.email || "Não informado"}</p>
                          <p className="text-sm text-slate-400">
                            Tempo para revender: {reseller.resellerExpiresAt
                              ? new Date(reseller.resellerExpiresAt).toLocaleDateString("pt-BR")
                              : "Sem limite"}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          className="border-red-700 text-red-400 hover:bg-red-900/20 ml-4"
                          onClick={() => {
                            if (confirm("Tem certeza que deseja deletar este revendedor?")) {
                              deleteResellerMutation.mutate({ id: reseller.id });
                            }
                          }}
                          disabled={deleteResellerMutation.isPending}
                        >
                          <Trash2 size={18} />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}







































          {/* Create Client */}
          {activeTab === "create-client" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Criar Cliente Proxy</h1>
              <p className="text-slate-400">Funcionalidade para criar clientes vinculados a IPs específicos.</p>
            </div>
          )}

          {/* Create Key */}
          {activeTab === "create-key" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Criar Chave Key</h1>
              {generatedKey && (
                <div className="bg-green-900/20 border border-green-800/50 rounded-lg p-4 space-y-3">
                  <p className="text-green-400 font-medium">✓ Chave gerada com sucesso!</p>
                  <div className="bg-slate-900 rounded p-3 font-mono text-sm text-cyan-400 break-all flex justify-between items-center">
                    <span>{generatedKey.key}</span>
                    <button
                      onClick={() => handleCopyKey(generatedKey.key)}
                      className="ml-2 p-2 hover:bg-slate-800 rounded"
                    >
                      <Copy size={18} />
                    </button>
                  </div>
                  <p className="text-sm text-slate-400">
                    Expira em: {new Date(generatedKey.expiresAt).toLocaleDateString("pt-BR")}
                  </p>
                  <Button
                    variant="outline"
                    className="border-slate-700 text-slate-300"
                    onClick={() => setGeneratedKey(null)}
                  >
                    Fechar
                  </Button>
                </div>
              )}
              <form onSubmit={handleCreateKey} className="bg-slate-800 rounded-lg p-6 space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-2">Dias de Validade</label>
                  <input
                    type="number"
                    min="1"
                    max="365"
                    value={keyDays}
                    onChange={(e) => setKeyDays(parseInt(e.target.value))}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold"
                  disabled={createKeyMutation.isPending}
                >
                  {createKeyMutation.isPending ? "Gerando..." : "Gerar Chave"}
                </Button>
              </form>
            </div>
          )}

          {/* Active Keys */}
          {activeTab === "active-keys" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Chaves Keys Utilizadas</h1>
              <input
                type="text"
                placeholder="Buscar por chave ou IP..."
                value={searchActive}
                onChange={(e) => setSearchActive(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
              />
              {activeKeysQuery.isLoading ? (
                <p className="text-slate-400">Carregando...</p>
              ) : (
                <div className="space-y-3">
                  {activeKeysQuery.data
                    ?.filter(
                      (key) =>
                        key.key.toLowerCase().includes(searchActive.toLowerCase()) ||
                        (key.clientIp?.toLowerCase().includes(searchActive.toLowerCase()) ?? false)
                    )
                    .map((key) => (
                      <div
                        key={key.id}
                        className="bg-slate-800 rounded-lg p-4 flex justify-between items-center"
                      >
                        <div>
                          <p className="font-mono text-cyan-400">{key.key}</p>
                          <p className="text-sm text-slate-400">IP: {key.clientIp || "Não sincronizado"}</p>
                          <p className="text-xs text-slate-500">
                            Expira em: {new Date(key.expiresAt).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                        <button
                          onClick={() => handleCopyKey(key.key)}
                          className="p-2 hover:bg-slate-700 rounded"
                        >
                          <Copy size={18} className="text-cyan-400" />
                        </button>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}

          {/* Deactivated Keys */}
          {activeTab === "deactivated-keys" && (
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">Chaves Keys Desativadas/Expiradas</h1>
              <input
                type="text"
                placeholder="Buscar por chave..."
                value={searchDeactivated}
                onChange={(e) => setSearchDeactivated(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
              />
              {deactivatedKeysQuery.isLoading ? (
                <p className="text-slate-400">Carregando...</p>
              ) : (
                <div className="space-y-3">
                  {deactivatedKeysQuery.data
                    ?.filter((key) =>
                      key.key.toLowerCase().includes(searchDeactivated.toLowerCase())
                    )
                    .map((key) => (
                      <div
                        key={key.id}
                        className="bg-slate-800 rounded-lg p-4"
                      >
                        <p className="font-mono text-red-400">{key.key}</p>
                        <p className="text-sm text-slate-400">
                          Motivo: {key.reason === "expired" ? "Expirada" : "Desativada manualmente"}
                        </p>
                        <p className="text-xs text-slate-500">
                          Desativada em: {new Date(key.deactivatedAt).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
