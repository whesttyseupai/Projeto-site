import { useState, useEffect } from "react";
import { MapPin, Wifi, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function CheckerIp() {
  const [keyInput, setKeyInput] = useState("");
  const [detectedIp, setDetectedIp] = useState("");
  const [syncIp, setSyncIp] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error" | "info";
    text: string;
  } | null>(null);
  const [, navigate] = useLocation();

  // Check key validity
  const checkKeyQuery = trpc.proxyKeys.check.useQuery(
    { key: keyInput },
    { enabled: keyInput.length > 0 }
  );

  // Update client IP mutation
  const updateIpMutation = trpc.proxyKeys.updateClientIp.useMutation({
    onSuccess: () => {
      setMessage({
        type: "success",
        text: "IP sincronizado com sucesso!",
      });
      setTimeout(() => setMessage(null), 3000);
    },
    onError: (error) => {
      setMessage({
        type: "error",
        text: error.message || "Erro ao sincronizar IP",
      });
    },
  });

  // Detect client IP
  useEffect(() => {
    const detectIp = async () => {
      try {
        const response = await fetch("https://api.ipify.org?format=json");
        const data = await response.json();
        setDetectedIp(data.ip);
        setSyncIp(data.ip);
      } catch (error) {
        console.error("Failed to detect IP:", error);
        setMessage({
          type: "error",
          text: "Não foi possível detectar seu IP",
        });
      }
    };

    detectIp();
  }, []);

  const handleDetectIp = async () => {
    try {
      setLoading(true);
      const response = await fetch("https://api.ipify.org?format=json");
      const data = await response.json();
      setDetectedIp(data.ip);
      setSyncIp(data.ip);
      setMessage({
        type: "info",
        text: "IP detectado com sucesso",
      });
    } catch (error) {
      setMessage({
        type: "error",
        text: "Erro ao detectar IP",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSyncIp = async () => {
    if (!keyInput) {
      setMessage({
        type: "error",
        text: "Por favor, insira sua chave de acesso",
      });
      return;
    }

    if (!syncIp) {
      setMessage({
        type: "error",
        text: "Por favor, insira um IP válido",
      });
      return;
    }

    setLoading(true);
    try {
      await updateIpMutation.mutateAsync({
        keyString: keyInput,
        clientIp: syncIp,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="text-2xl font-bold text-cyan-400">Proxy Oficial</div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-2xl mx-auto px-4 py-8 space-y-8">
        {/* Intro text */}
        <div className="text-center space-y-3">
          <p className="text-slate-400 text-sm leading-relaxed">
            Sincronize seu endereço IP com sua chave de acesso para começar a usar o proxy.
          </p>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

        {/* Access key section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            SUA KEY DE ACESSO
          </label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400">
              <Wifi size={20} />
            </div>
            <input
              type="text"
              placeholder="Insira sua chave de acesso"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              className="w-full bg-slate-800/50 border border-slate-700 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
            />
          </div>
          {keyInput && (
            <div className="text-xs">
              {checkKeyQuery.isLoading ? (
                <span className="text-slate-400">Verificando chave...</span>
              ) : checkKeyQuery.data?.isValid ? (
                <span className="text-green-400">✓ Chave válida</span>
              ) : (
                <span className="text-red-400">✕ Chave inválida</span>
              )}
            </div>
          )}
        </div>

        {/* IP detection section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            NOVO ENDEREÇO DE IP
          </label>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400">
                <MapPin size={20} />
              </div>
              <input
                type="text"
                placeholder="Seu IP será detectado automaticamente"
                value={syncIp}
                onChange={(e) => setSyncIp(e.target.value)}
                className="w-full bg-slate-800/50 border border-slate-700 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
              />
            </div>
            <Button
              className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-semibold px-6 rounded-lg transition disabled:opacity-50"
              onClick={handleDetectIp}
              disabled={loading}
            >
              {loading ? (
                <RefreshCw size={18} className="animate-spin" />
              ) : (
                "Detectar IP"
              )}
            </Button>
          </div>
        </div>

        {/* Sync button */}
        <Button
          className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold py-3 rounded-lg text-base transition disabled:opacity-50"
          onClick={handleSyncIp}
          disabled={loading || !keyInput || !syncIp}
        >
          {loading ? (
            <div className="flex items-center gap-2">
              <RefreshCw size={18} className="animate-spin" />
              Sincronizando...
            </div>
          ) : (
            "Sincronizar IP"
          )}
        </Button>

        {/* Status message */}
        {message && (
          <div
            className={`rounded-lg p-4 ${
              message.type === "success"
                ? "bg-green-900/20 border border-green-800/50"
                : message.type === "error"
                  ? "bg-red-900/20 border border-red-800/50"
                  : "bg-blue-900/20 border border-blue-800/50"
            }`}
          >
            <p
              className={`text-sm font-medium ${
                message.type === "success"
                  ? "text-green-400"
                  : message.type === "error"
                    ? "text-red-400"
                    : "text-blue-400"
              }`}
            >
              {message.type === "success" && "✓ "}
              {message.type === "error" && "✕ "}
              {message.text}
            </p>
          </div>
        )}

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

        {/* Proxy servers section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            SERVIDORES PROXY
          </label>

          <div className="space-y-3">
            {/* HS PESCOÇO */}
            <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="text-cyan-400" size={20} />
                  <span className="font-semibold">HS PESCOÇO</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-xs font-semibold text-green-400">
                    ONLINE
                  </span>
                </div>
              </div>
              <div className="space-y-2 text-sm text-slate-300">
                <div className="flex justify-between">
                  <span>Servidor:</span>
                  <span className="font-mono">69.197.142.47</span>
                </div>
                <div className="flex justify-between">
                  <span>Porta:</span>
                  <span className="font-mono">10043</span>
                </div>
              </div>
            </div>

            {/* HS PEITO */}
            <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="text-cyan-400" size={20} />
                  <span className="font-semibold">HS PEITO</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-xs font-semibold text-green-400">
                    ONLINE
                  </span>
                </div>
              </div>
              <div className="space-y-2 text-sm text-slate-300">
                <div className="flex justify-between">
                  <span>Servidor:</span>
                  <span className="font-mono">69.197.142.47</span>
                </div>
                <div className="flex justify-between">
                  <span>Porta:</span>
                  <span className="font-mono">10043</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Back button */}
        <Button
          variant="outline"
          className="w-full border-slate-700 text-slate-300 hover:bg-slate-800"
          onClick={() => navigate("/")}
        >
          Voltar para Home
        </Button>
      </main>
    </div>
  );
}
