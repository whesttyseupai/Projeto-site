import { useState } from "react";
import { Menu, X, MapPin, Wifi } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleCertificateClick = () => {
    window.open(
      "https://www.mediafire.com/file/ami2lr9n62n8ga9/mitmproxy-ca-cert.pem/file",
      "_blank"
    );
  };

  const handleSupportClick = () => {
    window.open(
      "https://chat.whatsapp.com/EKU9RFgEnJn91p5QkHyr7O?s=cl&p=i&ilr=4",
      "_blank"
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header with hamburger menu */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-cyan-400">Proxy Oficial</div>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden p-2 hover:bg-slate-800 rounded-lg transition"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-slate-800 bg-slate-900">
            <div className="px-4 py-3 space-y-2">
              <button
                onClick={handleCertificateClick}
                className="w-full text-left px-4 py-2 hover:bg-slate-800 rounded-lg transition text-sm"
              >
                Certificado
              </button>
              <button
                onClick={handleSupportClick}
                className="w-full text-left px-4 py-2 hover:bg-slate-800 rounded-lg transition text-sm"
              >
                Suporte VIP
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="max-w-2xl mx-auto px-4 py-8 space-y-8">
        {/* Intro text */}
        <div className="text-center space-y-3">
          <p className="text-slate-400 text-sm leading-relaxed">
            segundos. O sistema detecta e configura tudo automaticamente para você.
          </p>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

        {/* Access key section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            SUA KEY DE ACESSO
          </label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400">
              <Wifi size={20} />
            </div>
            <input
              type="text"
              placeholder="KEY-NXLS-G4RM-73M4"
              className="w-full bg-slate-800/50 border border-slate-700 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
              readOnly
            />
          </div>
        </div>

        {/* IP detection section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            NOVO ENDEREÇO DE IP
          </label>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-cyan-400">
                <MapPin size={20} />
              </div>
              <input
                type="text"
                placeholder="178.229.7109"
                className="w-full bg-slate-800/50 border border-slate-700 rounded-lg pl-12 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
                readOnly
              />
            </div>
            <Button
              className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-semibold px-6 rounded-lg transition"
              onClick={() => {}}
            >
              Detectar IP
            </Button>
          </div>
        </div>

        {/* Sync button */}
        <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold py-3 rounded-lg text-base transition">
          Sincronizar IP
        </Button>

        {/* Status message */}
        <div className="bg-red-900/20 border border-red-800/50 rounded-lg p-4">
          <p className="text-red-400 text-sm font-medium">
            ✕ Telegram em cooldown por 3 min. Tente novamente mais tarde.
          </p>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

        {/* Proxy servers section */}
        <div className="space-y-4">
          <label className="text-xs font-semibold text-slate-400 tracking-wider">
            SERVIDORES PROXY
          </label>

          <div className="space-y-3">
            {/* HS PESCOÇO */}
            <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="text-cyan-400" size={20} />
                  <span className="font-semibold">HS PESCOÇO</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-xs font-semibold text-green-400">
                    ONLINE
                  </span>
                </div>
              </div>
              <div className="space-y-2 text-sm text-slate-300">
                <div className="flex justify-between">
                  <span>Servidor:</span>
                  <span className="font-mono">155.117.40.185</span>
                </div>
                <div className="flex justify-between">
                  <span>Porta:</span>
                  <span className="font-mono">10056</span>
                </div>
              </div>
              <button className="text-cyan-400 hover:text-cyan-300 text-sm font-medium transition">
                ℹ Mais informações
              </button>
            </div>

            {/* HS PEITO */}
            <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="text-cyan-400" size={20} />
                  <span className="font-semibold">HS PEITO</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-xs font-semibold text-green-400">
                    ONLINE
                  </span>
                </div>
              </div>
              <div className="space-y-2 text-sm text-slate-300">
                <div className="flex justify-between">
                  <span>Servidor:</span>
                  <span className="font-mono">155.117.40.185</span>
                </div>
                <div className="flex justify-between">
                  <span>Porta:</span>
                  <span className="font-mono">10055</span>
                </div>
              </div>
              <button className="text-cyan-400 hover:text-cyan-300 text-sm font-medium transition">
                ℹ Mais informações
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Desktop menu (hidden on mobile) */}
      <div className="hidden md:block fixed top-4 right-4 space-y-2">
        <button
          onClick={handleCertificateClick}
          className="block w-full text-right px-4 py-2 hover:text-cyan-400 transition text-sm"
        >
          Certificado
        </button>
        <button
          onClick={handleSupportClick}
          className="block w-full text-right px-4 py-2 hover:text-cyan-400 transition text-sm"
        >
          Suporte VIP
        </button>
      </div>
    </div>
  );
}
