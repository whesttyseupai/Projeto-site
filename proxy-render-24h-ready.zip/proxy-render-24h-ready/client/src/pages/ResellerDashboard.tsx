import { useState } from "react";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function ResellerDashboard() {
  const [, navigate] = useLocation();

  // Form states
  const [keyDays, setKeyDays] = useState(30);
  const [generatedKey, setGeneratedKey] = useState<{ key: string; expiresAt: Date } | null>(null);

  // Mutations
  const createKeyMutation = trpc.proxyKeys.create.useMutation({
    onSuccess: (data) => {
      setGeneratedKey(data);
      setKeyDays(30);
      activeKeysQuery.refetch();
    },
    onError: (error) => {
      alert(error.message || "Erro ao criar chave");
    },
  });

  const logoutMutation = trpc.reseller.logout.useMutation({
    onSuccess: () => {
      navigate("/proxysystem/login/revendedor");
    },
  });

  // Queries
  const activeKeysQuery = trpc.proxyKeys.listActive.useQuery();

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    const newKey = `KEY-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    await createKeyMutation.mutateAsync({
      key: newKey,
      days: keyDays,
      createdBy: 1,
      createdByType: "reseller",
    });
  };

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
  };

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    alert("Chave copiada para clipboard!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-cyan-400">Proxy Oficial - Revendedor</div>
          <Button
            variant="outline"
            className="border-red-700 text-red-400 hover:bg-red-900/20"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut size={18} />
            Sair
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Create Key Section */}
        <div className="space-y-6">
          <h1 className="text-3xl font-bold">Gerar Chave Key</h1>
          <form onSubmit={handleCreateKey} className="bg-slate-800/30 border border-slate-700 rounded-lg p-6 space-y-4">
            {generatedKey && (
              <div className="bg-green-900/20 border border-green-700 rounded-lg p-4 space-y-2">
                <p className="text-green-400 font-semibold">✓ Chave Gerada com Sucesso!</p>
                <p className="text-sm text-slate-300 font-mono break-all">{generatedKey.key}</p>
                <p className="text-xs text-slate-400">Válida até: {new Date(generatedKey.expiresAt).toLocaleDateString("pt-BR")}</p>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-green-700 text-green-400 hover:bg-green-900/20"
                  onClick={() => {
                    navigator.clipboard.writeText(generatedKey.key);
                    alert("Chave copiada para clipboard!");
                  }}
                >
                  Copiar Chave
                </Button>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium mb-2">
                Dias de Validade
              </label>
              <input
                type="number"
                min="1"
                max="365"
                value={keyDays}
                onChange={(e) => setKeyDays(parseInt(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
            <Button
              type="submit"
              className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold w-full"
              disabled={createKeyMutation.isPending}
            >
              {createKeyMutation.isPending ? "Gerando..." : "Gerar Chave Automática"}
            </Button>
          </form>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

        {/* Active Keys Section */}
        <div className="space-y-6">
          <h1 className="text-3xl font-bold">Minhas Chaves</h1>
          {activeKeysQuery.isLoading ? (
            <p className="text-slate-400">Carregando...</p>
          ) : activeKeysQuery.data && activeKeysQuery.data.length > 0 ? (
            <div className="space-y-3">
              {activeKeysQuery.data.map((key) => (
                <div
                  key={key.id}
                  className="bg-slate-800/30 border border-slate-700 rounded-lg p-4 flex justify-between items-center"
                >
                  <div>
                    <p className="font-mono text-cyan-400">{key.key}</p>
                    <p className="text-xs text-slate-400">
                      Expira em: {new Date(key.expiresAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-cyan-700 text-cyan-400 hover:bg-cyan-900/20"
                    onClick={() => handleCopyKey(key.key)}
                  >
                    Copiar
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400">Nenhuma chave gerada ainda</p>
          )}
        </div>
      </main>
    </div>
  );
}
