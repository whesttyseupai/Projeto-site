# Proxy System - Guia de Configuração

## Visão Geral

Este é um sistema completo de gerenciamento de proxies com painel administrativo, painel de revendedor e página pública para sincronização de IPs.

## Estrutura do Projeto

```
proxy-system/
├── client/                 # Frontend React
│   └── src/
│       └── pages/
│           ├── Home.tsx               # Página pública (/)
│           ├── CheckerIp.tsx          # Página de sincronização (/checker-ip)
│           ├── AdminLogin.tsx         # Login admin (/admin)
│           ├── AdminDashboard.tsx     # Painel admin (/admin/dashboard)
│           ├── ResellerLogin.tsx      # Login revendedor (/proxysystem/login/revendedor)
│           └── ResellerDashboard.tsx  # Painel revendedor (/reseller/dashboard)
├── server/                 # Backend Node.js
│   ├── auth.ts            # Autenticação com bcrypt
│   ├── proxyHelpers.ts    # Gerenciamento de chaves no banco
│   ├── proxyApi.ts        # Integração com API externa
│   └── routers.ts         # Endpoints tRPC
├── drizzle/               # Schema e migrações de banco de dados
└── todo.md               # Rastreamento de funcionalidades
```

## Configuração Inicial

### 1. Variáveis de Ambiente

Você precisa adicionar a chave de API do proxy externo. Acesse o painel de configuração do projeto e adicione:

**Variável:** `PROXY_API_KEY`
**Valor:** Sua chave de API para 69.197.142.47:10043
**Descrição:** Chave de autenticação para os endpoints de proxy

### 2. Credenciais Admin

As credenciais do admin são inicializadas automaticamente na primeira execução:
- **Usuário:** `Macelos-ruis`
- **Senha:** `proxy&system`

Acesse o painel admin em `/admin` para fazer login.

## Funcionalidades Principais

### Página Pública (/)

A página inicial exibe os servidores proxy disponíveis com um design dark moderno. Inclui:
- Menu hambúrguer com links para certificado e suporte
- Exibição dos servidores HS PESCOÇO e HS PEITO
- Campos para entrada de chave e sincronização de IP

### Página de Sincronização (/checker-ip)

Permite que usuários finais sincronizem seus IPs com suas chaves:
- Validação de chave via API
- Detecção automática de IP
- Sincronização com o servidor de proxy

### Painel Admin (/admin)

Acesso restrito para administrador com funcionalidades:
- **Criar Revendedor:** Criar contas de revendedor com acesso limitado
- **Criar Chave Key:** Gerar chaves com validade em dias
- **Chaves Keys Utilizadas:** Listar chaves ativas com IPs sincronizados
- **Chaves Keys Desativadas/Expiradas:** Histórico de chaves canceladas ou expiradas

### Painel Revendedor (/proxysystem/login/revendedor)

Acesso restrito para revendedores com funcionalidades limitadas:
- **Gerar Chave Key:** Criar chaves com validade customizável
- **Minhas Chaves:** Listar chaves criadas pelo revendedor

## Integração com API Externa

O sistema se integra com a API de proxy em `http://69.197.142.47:10043`. Os endpoints utilizados são:

| Endpoint | Método | Descrição |
|----------|--------|-----------|
| `/{API_KEY}/check?key=TEST_KEY` | GET | Verificar se uma chave é válida |
| `/{API_KEY}/generate?key=NEW_KEY&days=10` | GET | Gerar uma nova chave |
| `/{API_KEY}/update?key=USER_KEY&ip=1.2.3.4` | GET | Atualizar IP de uma chave |
| `/{API_KEY}/delete?key=USER_KEY` | GET | Deletar uma chave |
| `/{API_KEY}/batch/generate?name=file1&count=5&days=10` | GET | Gerar múltiplas chaves |
| `/{API_KEY}/batch/delete?name=file1` | GET | Deletar múltiplas chaves |

## Banco de Dados

O sistema utiliza MySQL/TiDB com as seguintes tabelas:

- **admin_credentials:** Armazena credenciais do admin com hash bcrypt
- **resellers:** Contas de revendedor com senhas hasheadas
- **proxy_keys:** Chaves de proxy com validade e status
- **proxy_clients:** Registro de sincronização de IPs
- **deactivated_keys:** Histórico de chaves canceladas/expiradas

## Fluxo de Autenticação

### Admin
1. Acesse `/admin`
2. Faça login com `Macelos-ruis` / `proxy&system`
3. Acesso ao painel completo em `/admin/dashboard`

### Revendedor
1. Admin cria revendedor no painel
2. Revendedor acessa `/proxysystem/login/revendedor`
3. Faz login com credenciais fornecidas
4. Acesso ao painel restrito em `/reseller/dashboard`

### Usuário Final
1. Acessa `/checker-ip`
2. Insere sua chave de proxy
3. Clica em "Sincronizar IP"
4. Sistema registra o IP no servidor de proxy

## Segurança

- Todas as senhas são armazenadas com hash bcrypt (10 rounds)
- Credenciais nunca são expostas no HTML ou frontend
- Sessões são gerenciadas via cookies seguros
- API externa é autenticada via chave de API

## Próximos Passos

1. Configure a variável `PROXY_API_KEY` com sua chave de API
2. Teste o login admin em `/admin`
3. Crie um revendedor de teste
4. Teste a geração de chaves
5. Teste a sincronização de IP em `/checker-ip`

## Troubleshooting

**Erro ao conectar à API de proxy:**
- Verifique se `PROXY_API_KEY` está configurada corretamente
- Confirme que o servidor de proxy em `69.197.142.47:10043` está acessível
- Verifique os logs do servidor para mais detalhes

**Chaves não aparecem na listagem:**
- Verifique se as chaves foram criadas com sucesso (verifique os logs)
- Confirme que a chave foi gerada na API externa
- Verifique se o banco de dados está sincronizado

**Erro de autenticação:**
- Verifique as credenciais do admin
- Limpe os cookies do navegador e tente novamente
- Verifique se o banco de dados foi inicializado corretamente
