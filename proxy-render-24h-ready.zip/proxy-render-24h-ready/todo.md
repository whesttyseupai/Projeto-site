# Proxy System - TODO

## Banco de Dados
- [x] Schema com tabelas: adminCredentials, resellers, proxyKeys, proxyClients, deactivatedKeys
- [x] Gerar migração via drizzle-kit
- [x] Aplicar migração ao banco de dados

## Autenticação Admin
- [x] Implementar hash de senha com bcrypt
- [x] Criar endpoint POST /api/admin/login com validação segura
- [x] Criar endpoint POST /api/admin/logout
- [ ] Implementar middleware de proteção para rotas admin
- [x] Criar session/JWT para admin

## Página Pública (/)
- [x] Design dark idêntico ao site original
- [x] Exibir servidores proxy (HS PESCOÇO e HS PEITO)
- [x] Menu hambúrguer com links:
  - [x] Certificado (link Mediafire)
  - [x] Suporte VIP (link WhatsApp)
- [x] Seção "SUA KEY DE ACESSO" com campo de entrada
- [x] Botão "Detectar IP"
- [x] Seção "NOVO ENDEREÇO DE IP" com campo de entrada
- [x] Botão "Sincronizar IP"
- [x] Mensagens de status/erro

## Página /checker-ip
- [x] Campo para inserir chave key
- [x] Validação de chave via API
- [x] Botão "Sincronizar IP"
- [x] Integração com endpoint: GET /YOUR_API_KEY/update?key=USER_KEY&ip=1.2.3.4
- [x] Exibição de status de sincronização
- [x] Listagem de servidores proxy disponíveis

## Painel Admin (/admin)
- [x] Página de login com credenciais seguras
- [x] Menu hambúrguer lateral com navegação
- [x] Dashboard principal

### Aba: Criar Revendedor
- [x] Formulário com campos: username, email, password
- [x] Validação de dados
- [x] Criação de conta de revendedor
- [x] Armazenamento de senha com hash
- [x] Mensagens de sucesso/erro

### Aba: Criar Cliente Proxy
- [ ] Formulário para criar chave vinculada a IP
- [ ] Campo de busca de IP
- [ ] Integração com API: /YOUR_API_KEY/generate?key=NEW_KEY&days=10
- [ ] Validação de IP
- [ ] Armazenamento de cliente no banco

### Aba: Criar Chave Key
- [x] Gerador de keys único
- [x] Campo para seleção de dias de validade
- [x] Botão para gerar chave
- [x] Integração com API: /YOUR_API_KEY/generate?key=NEW_KEY&days=10
- [ ] Suporte para geração em lote: /YOUR_API_KEY/batch/generate?name=file1&count=5&days=10
- [x] Exibição da chave gerada
- [x] Cópia para clipboard

### Aba: Chaves Keys Utilizadas
- [x] Listagem de chaves ativas
- [x] Exibição do IP do cliente que utilizou
- [x] Integração com API: /YOUR_API_KEY/check?key=TEST_KEY
- [x] Filtros e busca
- [x] Status de atividade

### Aba: Chaves Keys Desativadas/Expiradas
- [x] Listagem de chaves canceladas manualmente
- [x] Listagem de chaves expiradas
- [x] Integração com API: /YOUR_API_KEY/delete?key=USER_KEY
- [ ] Suporte para exclusão em lote: /YOUR_API_KEY/batch/delete?name=file1
- [x] Data de desativação/expiração
- [x] Motivo da desativação

## Painel Revendedor (/proxysystem/login/revendedor)
- [x] Página de login para revendedores
- [x] Autenticação de revendedor
- [x] Dashboard restrito
- [x] Aba: Criar Chave Key (apenas)
- [x] Sem acesso a "Criar Revendedor"
- [x] Geração de chaves com seleção de dias
- [x] Listagem de chaves criadas

## Integração com API Externa
- [x] Configurar base URL: http://69.197.142.47:10043
- [x] Endpoint: /YOUR_API_KEY/check?key=TEST_KEY
- [x] Endpoint: /YOUR_API_KEY/generate?key=NEW_KEY&days=10
- [x] Endpoint: /YOUR_API_KEY/update?key=USER_KEY&ip=1.2.3.4
- [x] Endpoint: /YOUR_API_KEY/delete?key=USER_KEY
- [x] Endpoint: /YOUR_API_KEY/batch/generate?name=file1&count=5&days=10
- [x] Endpoint: /YOUR_API_KEY/batch/delete?name=file1
- [x] Tratamento de erros e timeouts
- [x] Logging de requisições

## Testes
- [x] Testes de autenticação admin
- [x] Testes de criação de revendedor
- [x] Testes de geração de chaves
- [x] Testes de sincronização de IP
- [x] Testes de integração com API externa

## Deploy e Entrega
- [x] Verificar todas as funcionalidades
- [x] Testar fluxos completos
- [ ] Criar checkpoint final
- [ ] Gerar ZIP para download
