import bcrypt from "bcrypt";
import { getDb } from "./db";
import { adminCredentials, resellers } from "../drizzle/schema";
import { eq } from "drizzle-orm";

const SALT_ROUNDS = 10;

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

/**
 * Compare a plain password with a hashed password
 */
export async function verifyPassword(
  plainPassword: string,
  hashedPassword: string
): Promise<boolean> {
  return bcrypt.compare(plainPassword, hashedPassword);
}

/**
 * Initialize admin credentials if not exists
 */
export async function initializeAdminCredentials(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Auth] Cannot initialize admin: database not available");
    return;
  }

  try {
    const existing = await db
      .select()
      .from(adminCredentials)
      .where(eq(adminCredentials.username, "marcelo-ruis"))
      .limit(1);

    if (existing.length === 0) {
      const passwordHash = await hashPassword("proxy&system");
      await db.insert(adminCredentials).values({
        username: "marcelo-ruis",
        passwordHash,
      });
      console.log("[Auth] Admin credentials initialized");
    }
  } catch (error) {
    console.error("[Auth] Failed to initialize admin credentials:", error);
  }
}

/**
 * Verify admin credentials
 */
export async function verifyAdminCredentials(
  username: string,
  password: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Auth] Cannot verify admin: database not available");
    return false;
  }

  try {
    const admin = await db
      .select()
      .from(adminCredentials)
      .where(eq(adminCredentials.username, username))
      .limit(1);

    if (admin.length === 0) {
      return false;
    }

    return verifyPassword(password, admin[0].passwordHash);
  } catch (error) {
    console.error("[Auth] Failed to verify admin credentials:", error);
    return false;
  }
}

/**
 * Verify reseller credentials
 */
export async function verifyResellerCredentials(
  username: string,
  password: string
): Promise<{ id: number; username: string; email: string | null } | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Auth] Cannot verify reseller: database not available");
    return null;
  }

  try {
    const reseller = await db
      .select()
      .from(resellers)
      .where(eq(resellers.username, username))
      .limit(1);

    if (reseller.length === 0) {
      return null;
    }

    if (!reseller[0].isActive) {
      return null;
    }

    const isValid = await verifyPassword(password, reseller[0].passwordHash);
    if (!isValid) {
      return null;
    }

    return {
      id: reseller[0].id,
      username: reseller[0].username,
      email: reseller[0].email,
    };
  } catch (error) {
    console.error("[Auth] Failed to verify reseller credentials:", error);
    return null;
  }
}

/**
 * Create a new reseller
 */
export async function createReseller(
  username: string,
  password: string,
  email?: string,
  resellerDays?: number
): Promise<{ id: number; username: string } | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Auth] Cannot create reseller: database not available");
    return null;
  }

  try {
    const passwordHash = await hashPassword(password);
    const resellerExpiresAt = resellerDays
      ? new Date(Date.now() + resellerDays * 24 * 60 * 60 * 1000)
      : undefined;

    await db.insert(resellers).values({
      username,
      passwordHash,
      email,
      resellerExpiresAt,
    });

    // Fetch the created reseller to get the ID
    const created = await db
      .select()
      .from(resellers)
      .where(eq(resellers.username, username))
      .limit(1);

    if (created.length === 0) {
      return null;
    }

    return {
      id: created[0].id,
      username: created[0].username,
    };
  } catch (error) {
    console.error("[Auth] Failed to create reseller:", error);
    return null;
  }
}
