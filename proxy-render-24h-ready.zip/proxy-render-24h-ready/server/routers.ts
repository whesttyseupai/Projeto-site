import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  verifyAdminCredentials,
  initializeAdminCredentials,
  verifyResellerCredentials,
  createReseller,
} from "./auth";
import {
  createProxyKey,
  getActiveProxyKeysWithClients,
  getDeactivatedKeys,
  updateProxyKeyClientIp,
  deactivateProxyKey,
  findProxyKeyByString,
  autoExpireKeys,
} from "./proxyHelpers";
import {
  checkProxyKey,
  generateProxyKey,
  updateProxyKeyIp,
  deleteProxyKey,
} from "./proxyApi";
import { TRPCError } from "@trpc/server";
import { getDb } from "./db";
import { resellers } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Initialize admin credentials on startup
initializeAdminCredentials();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Admin authentication
  admin: router({
    login: publicProcedure
      .input(
        z.object({
          username: z.string().min(1),
          password: z.string().min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const isValid = await verifyAdminCredentials(
          input.username,
          input.password
        );

        if (!isValid) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid credentials",
          });
        }

        // Set admin session cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, "admin_session", {
          ...cookieOptions,
          maxAge: 24 * 60 * 60 * 1000, // 24 hours
        });

        return { success: true };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),
  }),

  // Reseller authentication
  reseller: router({
    login: publicProcedure
      .input(
        z.object({
          username: z.string().min(1),
          password: z.string().min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const reseller = await verifyResellerCredentials(
          input.username,
          input.password
        );

        if (!reseller) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid credentials",
          });
        }

        // Set reseller session cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, `reseller_${reseller.id}`, {
          ...cookieOptions,
          maxAge: 24 * 60 * 60 * 1000, // 24 hours
        });

        return { success: true, reseller };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),

    create: publicProcedure
      .input(
        z.object({
          username: z.string().min(1),
          password: z.string().min(6),
          email: z.string().email().optional(),
          resellerDays: z.number().min(1).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const result = await createReseller(
          input.username,
          input.password,
          input.email,
          input.resellerDays
        );

        if (!result) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create reseller",
          });
        }

        return result;
      }),

    list: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      try {
        const result = await db.select().from(resellers).where(eq(resellers.isActive, true));
        return result;
      } catch (error) {
        console.error("[Reseller] Failed to list resellers:", error);
        return [];
      }
    }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }
        try {
          await db
            .update(resellers)
            .set({ isActive: false })
            .where(eq(resellers.id, input.id));
          return { success: true };
        } catch (error) {
          console.error("[Reseller] Failed to delete reseller:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to delete reseller",
          });
        }
      }),
  }),

  // Proxy key management
  proxyKeys: router({
    // Create a new proxy key
    create: publicProcedure
      .input(
        z.object({
          key: z.string().min(1),
          days: z.number().min(1).max(365),
          createdBy: z.number(),
          createdByType: z.enum(["admin", "reseller"]),
        })
      )
      .mutation(async ({ input }) => {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + input.days);

        // First, generate the key in the external API
        const apiSuccess = await generateProxyKey(input.key, input.days);
        if (!apiSuccess) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to generate key in proxy API",
          });
        }

        // Then, store it in our database
        const result = await createProxyKey(
          input.key,
          input.createdBy,
          input.createdByType,
          expiresAt
        );

        if (!result) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create proxy key",
          });
        }

        return result;
      }),

    // Get all active keys with client info
    listActive: publicProcedure.query(async () => {
      await autoExpireKeys();
      return getActiveProxyKeysWithClients();
    }),

    // Get all deactivated/expired keys
    listDeactivated: publicProcedure.query(async () => {
      return getDeactivatedKeys();
    }),

    // Deactivate a key
    deactivate: publicProcedure
      .input(
        z.object({
          keyId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        const success = await deactivateProxyKey(input.keyId, "manual");

        if (!success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to deactivate key",
          });
        }

        return { success: true };
      }),

    // Update client IP for a key
    updateClientIp: publicProcedure
      .input(
        z.object({
          keyString: z.string().min(1),
          clientIp: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        // First, check if the key is valid in the external API
        const isValid = await checkProxyKey(input.keyString);
        if (!isValid) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Invalid proxy key",
          });
        }

        // Update the IP in the external API
        const apiSuccess = await updateProxyKeyIp(
          input.keyString,
          input.clientIp
        );
        if (!apiSuccess) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update IP in proxy API",
          });
        }

        // Find the key in our database
        const key = await findProxyKeyByString(input.keyString);
        if (!key) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Key not found in database",
          });
        }

        // Update the client IP in our database
        const success = await updateProxyKeyClientIp(key.id, input.clientIp);
        if (!success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update client IP",
          });
        }

        return { success: true };
      }),

    // Check if a key is valid
    check: publicProcedure
      .input(z.object({ key: z.string().min(1) }))
      .query(async ({ input }) => {
        const isValid = await checkProxyKey(input.key);
        return { isValid };
      }),
  }),
});

export type AppRouter = typeof appRouter;
