import axios from "axios";

const PROXY_API_BASE = "http://69.197.142.47:10043";
const PROXY_API_KEY = process.env.PROXY_API_KEY || "YOUR_API_KEY";

/**
 * Check if a proxy key is valid
 */
export async function checkProxyKey(key: string): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/check?key=${encodeURIComponent(key)}`;
    const response = await axios.get(url, { timeout: 5000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to check proxy key:", error);
    return false;
  }
}

/**
 * Generate a new proxy key
 */
export async function generateProxyKey(
  key: string,
  days: number
): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/generate?key=${encodeURIComponent(
      key
    )}&days=${days}`;
    const response = await axios.get(url, { timeout: 5000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to generate proxy key:", error);
    return false;
  }
}

/**
 * Update client IP for a proxy key
 */
export async function updateProxyKeyIp(
  key: string,
  ip: string
): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/update?key=${encodeURIComponent(
      key
    )}&ip=${encodeURIComponent(ip)}`;
    const response = await axios.get(url, { timeout: 5000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to update proxy key IP:", error);
    return false;
  }
}

/**
 * Delete a proxy key
 */
export async function deleteProxyKey(key: string): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/delete?key=${encodeURIComponent(key)}`;
    const response = await axios.get(url, { timeout: 5000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to delete proxy key:", error);
    return false;
  }
}

/**
 * Generate batch proxy keys
 */
export async function generateBatchProxyKeys(
  name: string,
  count: number,
  days: number
): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/batch/generate?name=${encodeURIComponent(
      name
    )}&count=${count}&days=${days}`;
    const response = await axios.get(url, { timeout: 10000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to generate batch proxy keys:", error);
    return false;
  }
}

/**
 * Delete batch proxy keys
 */
export async function deleteBatchProxyKeys(name: string): Promise<boolean> {
  try {
    const url = `${PROXY_API_BASE}/${PROXY_API_KEY}/batch/delete?name=${encodeURIComponent(
      name
    )}`;
    const response = await axios.get(url, { timeout: 10000 });
    return response.status === 200;
  } catch (error) {
    console.error("[ProxyApi] Failed to delete batch proxy keys:", error);
    return false;
  }
}
