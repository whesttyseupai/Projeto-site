import { getDb } from "./db";
import {
  proxyKeys,
  proxyClients,
  deactivatedKeys,
  ProxyKey,
} from "../drizzle/schema";
import { eq, and, lt, isNotNull } from "drizzle-orm";

/**
 * Generate a formatted key: KEY-XXXX-XXXX-XXXX
 */
export function generateFormattedKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const generateSegment = () => {
    let segment = '';
    for (let i = 0; i < 4; i++) {
      segment += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return segment;
  };
  return `KEY-${generateSegment()}-${generateSegment()}-${generateSegment()}`;
}

/**
 * Create a new proxy key
 */
export async function createProxyKey(
  key: string,
  createdBy: number,
  createdByType: "admin" | "reseller",
  expiresAt: Date
): Promise<ProxyKey | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot create key: database not available");
    return null;
  }

  try {
    await db.insert(proxyKeys).values({
      key,
      createdBy,
      createdByType,
      expiresAt,
      isActive: true,
      isExpired: false,
    });

    const created = await db
      .select()
      .from(proxyKeys)
      .where(eq(proxyKeys.key, key))
      .limit(1);

    return created.length > 0 ? created[0] : null;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to create proxy key:", error);
    return null;
  }
}

/**
 * Get all active proxy keys
 */
export async function getActiveProxyKeys(): Promise<ProxyKey[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot get keys: database not available");
    return [];
  }

  try {
    return await db
      .select()
      .from(proxyKeys)
      .where(
        and(
          eq(proxyKeys.isActive, true),
          eq(proxyKeys.isExpired, false),
          lt(proxyKeys.expiresAt, new Date())
        )
      );
  } catch (error) {
    console.error("[ProxyHelpers] Failed to get active keys:", error);
    return [];
  }
}

/**
 * Get all active proxy keys with client IP info
 */
export async function getActiveProxyKeysWithClients(): Promise<
  (ProxyKey & { clientIp: string | null })[]
> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot get keys: database not available");
    return [];
  }

  try {
    const keys = await db
      .select()
      .from(proxyKeys)
      .where(
        and(eq(proxyKeys.isActive, true), eq(proxyKeys.isExpired, false))
      );

    return keys;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to get active keys with clients:", error);
    return [];
  }
}

/**
 * Update client IP for a proxy key
 */
export async function updateProxyKeyClientIp(
  keyId: number,
  clientIp: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot update key: database not available");
    return false;
  }

  try {
    await db
      .update(proxyKeys)
      .set({
        clientIp,
        lastUsedAt: new Date(),
      })
      .where(eq(proxyKeys.id, keyId));

    // Also create or update client record
    const existing = await db
      .select()
      .from(proxyClients)
      .where(eq(proxyClients.keyId, keyId))
      .limit(1);

    if (existing.length > 0) {
      await db
        .update(proxyClients)
        .set({
          ipAddress: clientIp,
          lastSyncedAt: new Date(),
        })
        .where(eq(proxyClients.id, existing[0].id));
    } else {
      await db.insert(proxyClients).values({
        keyId,
        ipAddress: clientIp,
        lastSyncedAt: new Date(),
      });
    }

    return true;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to update proxy key client IP:", error);
    return false;
  }
}

/**
 * Deactivate a proxy key
 */
export async function deactivateProxyKey(
  keyId: number,
  reason: "manual" | "expired" = "manual"
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot deactivate key: database not available");
    return false;
  }

  try {
    const key = await db
      .select()
      .from(proxyKeys)
      .where(eq(proxyKeys.id, keyId))
      .limit(1);

    if (key.length === 0) {
      return false;
    }

    await db
      .update(proxyKeys)
      .set({
        isActive: false,
        isExpired: reason === "expired",
      })
      .where(eq(proxyKeys.id, keyId));

    await db.insert(deactivatedKeys).values({
      key: key[0].key,
      reason,
    });

    return true;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to deactivate proxy key:", error);
    return false;
  }
}

/**
 * Get deactivated/expired keys
 */
export async function getDeactivatedKeys() {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot get deactivated keys: database not available");
    return [];
  }

  try {
    return await db.select().from(deactivatedKeys);
  } catch (error) {
    console.error("[ProxyHelpers] Failed to get deactivated keys:", error);
    return [];
  }
}

/**
 * Find proxy key by key string
 */
export async function findProxyKeyByString(keyString: string): Promise<ProxyKey | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot find key: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(proxyKeys)
      .where(eq(proxyKeys.key, keyString))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to find proxy key:", error);
    return null;
  }
}

/**
 * Check if a proxy key is expired
 */
export async function isProxyKeyExpired(keyId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot check key: database not available");
    return true;
  }

  try {
    const key = await db
      .select()
      .from(proxyKeys)
      .where(eq(proxyKeys.id, keyId))
      .limit(1);

    if (key.length === 0) {
      return true;
    }

    return new Date() > key[0].expiresAt;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to check if key is expired:", error);
    return true;
  }
}

/**
 * Auto-expire keys that have passed their expiration date
 */
export async function autoExpireKeys(): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[ProxyHelpers] Cannot auto-expire keys: database not available");
    return 0;
  }

  try {
    const expiredKeys = await db
      .select()
      .from(proxyKeys)
      .where(
        and(
          eq(proxyKeys.isActive, true),
          eq(proxyKeys.isExpired, false),
          lt(proxyKeys.expiresAt, new Date())
        )
      );

    for (const key of expiredKeys) {
      await deactivateProxyKey(key.id, "expired");
    }

    return expiredKeys.length;
  } catch (error) {
    console.error("[ProxyHelpers] Failed to auto-expire keys:", error);
    return 0;
  }
}
